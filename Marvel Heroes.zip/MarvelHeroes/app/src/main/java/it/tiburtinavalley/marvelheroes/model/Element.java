package it.tiburtinavalley.marvelheroes.model;

import java.util.Collection;

public abstract class Element extends BasicElement {
    protected String description;

    public String getDescription() {
        return this.description;
    }

    ;
}

